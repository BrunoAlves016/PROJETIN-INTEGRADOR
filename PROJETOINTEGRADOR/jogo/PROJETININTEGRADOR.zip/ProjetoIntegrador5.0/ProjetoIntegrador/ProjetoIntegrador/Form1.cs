using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ProjetoIntegrador
{
    public partial class Form1 : Form
    {
        int inNullSliceIndex, inmoves = 0;
        List<Bitmap> lstOriginalPictureList = new List<Bitmap>();
        System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch();
        bool isPaused = false; // Vari�vel para controlar o estado de pausa

        public Form1()
        {
            InitializeComponent();
            lstOriginalPictureList.AddRange(new Bitmap[] {
                Properties.Resources._1, Properties.Resources._2, Properties.Resources._3,
                Properties.Resources._4, Properties.Resources._5, Properties.Resources._6,
                Properties.Resources._7, Properties.Resources._8, Properties.Resources._null
            });

            lblMovimento.Text += inmoves;
            lblTempo.Text = "00:00:00";

            foreach (Control control in gbPuzzleBox.Controls)
            {
                if (control is PictureBox)
                {
                    control.Click += new EventHandler(SwitchPictureBox);
                }
            }
        }

        void Shuffle()
        {
            do
            {
                int j;
                List<int> Indexes = new List<int>(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 });
                Random r = new Random();
                for (int i = 0; i < 9; i++)
                {
                    Indexes.Remove((j = Indexes[r.Next(0, Indexes.Count)]));
                    ((PictureBox)gbPuzzleBox.Controls[i]).Image = lstOriginalPictureList[j];
                    if (j == 8) inNullSliceIndex = i; // Armazena o �ndice do espa�o vazio
                }
            } while (CheckWin());
        }

        private void btnEmbaralhar_Click(object sender, EventArgs e)
        {
            DialogResult YesOrNo = DialogResult.None;

            if (lblTempo.Text != "00:00:00")
            {
                YesOrNo = MessageBox.Show("DESEJA REALMENTE EMBARALHAR?", "Rabbit Puzzle", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }

            if (YesOrNo == DialogResult.Yes || lblTempo.Text == "00:00:00")
            {
                Shuffle();
                timer.Reset();
                lblTempo.Text = "00:00:00";
                inmoves = 0;
                lblMovimento.Text = "MOVIMENTOS FEITOS : 0";
                timer.Start();
            }
        }

        private void SwitchPictureBox(object sender, EventArgs e)
        {
            if (lblTempo.Text == "00:00:00")
                timer.Start();

            int inPictureBoxIndex = gbPuzzleBox.Controls.IndexOf(sender as Control);

            if (inNullSliceIndex != inPictureBoxIndex)
            {
                List<int> FourBrothers = new List<int>(new int[] {
                    (inPictureBoxIndex % 3 == 0) ? -1 : inPictureBoxIndex - 1,
                    inPictureBoxIndex - 3,
                    (inPictureBoxIndex % 3 == 2) ? -1 : inPictureBoxIndex + 1,
                    inPictureBoxIndex + 3
                });

                if (FourBrothers.Contains(inNullSliceIndex))
                {
                    ((PictureBox)gbPuzzleBox.Controls[inNullSliceIndex]).Image = ((PictureBox)gbPuzzleBox.Controls[inPictureBoxIndex]).Image;
                    ((PictureBox)gbPuzzleBox.Controls[inPictureBoxIndex]).Image = lstOriginalPictureList[8];
                    inNullSliceIndex = inPictureBoxIndex;

                    lblMovimento.Text = "MOVIMENTOS FEITOS : " + (++inmoves);

                    if (CheckWin())
                    {
                        if (CheckWin())
                        {
                            timer.Stop();
                            (gbPuzzleBox.Controls[8] as PictureBox).Image = lstOriginalPictureList[8];
                            MessageBox.Show("PUZZLE CONCLU�DO COM SUCESSO!\nTempo decorrido: " + timer.Elapsed.ToString().Remove(8) + "\nTotal de movimentos: " + inmoves, "Rabbit Puzzle");

                            inmoves = 0;
                            lblMovimento.Text = "MOVIMENTOS FEITOS : 0";
                            lblTempo.Text = "00:00:00";
                            timer.Reset();
                            Shuffle();
                        }

                    }
                }
            }
        }

        bool CheckWin()
        {
            for (int i = 0; i < 8; i++)
            {
                if (!(gbPuzzleBox.Controls[i] as PictureBox).Image.Equals(lstOriginalPictureList[i]))
                    return false;
            }
            return true;
        }

        private void UpdateTimeElapsed(object sender, EventArgs e)
        {
            if (timer.Elapsed.ToString() != "00:00:00")
                lblTempo.Text = timer.Elapsed.ToString().Remove(8);

            btnPausar.Enabled = timer.Elapsed.ToString() != "00:00:00";

            // Modificar para 2 minutos
            if (timer.Elapsed.TotalMinutes >= 5) // Checa se o tempo total em minutos � igual ou maior que 2
            {
                timer.Stop();
                timer.Reset();
                lblMovimento.Text = "MOVIMENTOS FEITOS : 0";
                lblTempo.Text = "00:00:00";
                inmoves = 0;
                btnPausar.Enabled = false;

                MessageBox.Show("O tempo acabou. Tente novamente.", "Rabbit Puzzle");
                Shuffle();
                timer.Start();
            }
        }

        private void btnPausar_Click(object sender, EventArgs e)
        {
            // Verifica se o cron�metro est� rodando
            if (timer.IsRunning)
            {
                // Se o cron�metro est� rodando, pausa
                timer.Stop();

                // Desabilita a intera��o com os PictureBoxes
                foreach (Control control in gbPuzzleBox.Controls)
                {
                    if (control is PictureBox)
                    {
                        control.Enabled = false; // Desabilita as PictureBoxes
                    }
                }

                btnPausar.Text = "CONTINUAR"; // Muda o texto do bot�o para "CONTINUAR"
                btnEmbaralhar.Enabled = false; // Desabilita o bot�o de embaralhar
            }
            else
            {
                // Se o cron�metro est� parado, retoma
                timer.Start();

                // Habilita a intera��o com os PictureBoxes
                foreach (Control control in gbPuzzleBox.Controls)
                {
                    if (control is PictureBox)
                    {
                        control.Enabled = true; // Habilita as PictureBoxes
                    }
                }

                btnPausar.Text = "PAUSAR"; // Muda o texto do bot�o para "PAUSAR"
                btnEmbaralhar.Enabled = true; // Habilita o bot�o de embaralhar
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            Shuffle();
            timer.Start();
            btnPausar.Enabled = true;
        }

        private void lblTempo_Click(object sender, EventArgs e)
        {
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            // Pergunta ao usu�rio se deseja realmente sair
            DialogResult result = MessageBox.Show("DESEJA REALMENTE SAIR?", "Rabbit Puzzle", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Se o usu�rio clicar em "Sim", fecha o aplicativo
            if (result == DialogResult.Yes)
            {
                Application.Exit(); // Fecha a aplica��o
            }
            // Se o usu�rio clicar em "N�o", n�o faz nada e retorna ao jogo
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (CheckWin())
            {
                // Se o quebra-cabe�a est� completo, mostramos a mensagem de sucesso com tempo e movimentos
                timer.Stop();
                MessageBox.Show("PUZZLE CONCLU�DO COM SUCESSO!\nTempo decorrido: " + timer.Elapsed.ToString().Remove(8) + "\nTotal de movimentos: " + inmoves, "Rabbit Puzzle");

                // Reseta os contadores e embaralha para uma nova rodada
                inmoves = 0;
                lblMovimento.Text = "MOVIMENTOS FEITOS : 0";
                lblTempo.Text = "00:00:00";
                timer.Reset();
                Shuffle();
            }
            else
            {
                // Se o quebra-cabe�a n�o est� completo, mostra a op��o de continuar ou sair
                DialogResult result = MessageBox.Show("PUZZLE N�O COMPLETO. DESEJA CONTINUAR?", "Rabbit Puzzle", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.No)
                {
                    // Se o usu�rio escolhe "N�o", fecha o aplicativo
                    Application.Exit();
                }
            }
        }
    }
}
