﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIntegrador
{
    public partial class FrmLogin : Form{
        public FrmLogin()
        {
            InitializeComponent();
        }

        public static string NickCadastrado;
        public static string SenhaCadastrada;


        private void btnCadastrar_Click(object sender, EventArgs e)
        {
        FrmCadastro frmCadastro = new FrmCadastro();
        frmCadastro.ShowDialog(); // Exibe o formulário como modal para impedir outras interações
    }
        

        private void btnEntrar_Click(object sender, EventArgs e)
        {
        // Verifica se o usuário já está cadastrado
        if (txtNick.Text == NickCadastrado && txtSenha.Text == SenhaCadastrada)
        {
                // Se estiver cadastrado, abre o Form1
                FrmEntrar frmEntrar = new FrmEntrar();
                frmEntrar.Show();
                this.Hide();
            }
        else
        {
            // Exibe mensagem de erro caso os dados estejam incorretos
            MessageBox.Show("USUÁRIO OU SENHA INCORRETOS", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

        private void btnSair_Click(object sender, EventArgs e)
        {
        // Exibe uma mensagem de confirmação antes de sair
        DialogResult result = MessageBox.Show("DESEJA REALMENTE SAIR?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result == DialogResult.Yes)
        {
            Application.Exit();
        }
    }
        #region LIXEIRA
        private void button1_Click_1(object sender, EventArgs e)
        {

        }
        private void btnIniciar_Click(object sender, EventArgs e)
        {
            // Cria uma instância do Form1
            Form1 form1 = new Form1();

            // Mostra o Form1
            form1.Show();

            // Oculta ou fecha o formulário de login
            this.Hide(); // Para apenas esconder o FrmLogin
                         // this.Close(); // Para fechar o FrmLogin
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        #endregion
    }
}
