﻿namespace ProjetoIntegrador
{
    partial class FrmEntrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnIniciar = new Button();
            btnVoltar = new Button();
            SuspendLayout();
            // 
            // btnIniciar
            // 
            btnIniciar.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIniciar.Location = new Point(334, 343);
            btnIniciar.Name = "btnIniciar";
            btnIniciar.Size = new Size(156, 72);
            btnIniciar.TabIndex = 0;
            btnIniciar.Text = "INICIAR";
            btnIniciar.UseVisualStyleBackColor = true;
            btnIniciar.Click += btnIniciar_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVoltar.Location = new Point(334, 435);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(156, 72);
            btnVoltar.TabIndex = 1;
            btnVoltar.Text = "VOLTAR";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // FrmEntrar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.resized_fotoefeitos;
            ClientSize = new Size(841, 582);
            Controls.Add(btnVoltar);
            Controls.Add(btnIniciar);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmEntrar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmEntrar";
            ResumeLayout(false);
        }

        #endregion

        private Button btnIniciar;
        private Button btnVoltar;
    }
}