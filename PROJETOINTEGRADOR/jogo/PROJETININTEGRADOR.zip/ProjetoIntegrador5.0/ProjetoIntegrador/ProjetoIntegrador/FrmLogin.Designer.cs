﻿namespace ProjetoIntegrador
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSair = new Button();
            btnCadastrar = new Button();
            txtNick = new TextBox();
            txtSenha = new TextBox();
            label2 = new Label();
            label3 = new Label();
            btnEntrar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Showcard Gothic", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(85, 54);
            label1.Name = "label1";
            label1.Size = new Size(518, 44);
            label1.TabIndex = 0;
            label1.Text = "BEM-VINDO AO PUZZLE IMAGE";
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Showcard Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(271, 333);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(139, 52);
            btnSair.TabIndex = 2;
            btnSair.Text = "SAIR";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Font = new Font("Showcard Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastrar.Location = new Point(430, 333);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(139, 52);
            btnCadastrar.TabIndex = 3;
            btnCadastrar.Text = "CADASTRE-SE";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // txtNick
            // 
            txtNick.Location = new Point(246, 195);
            txtNick.Name = "txtNick";
            txtNick.Size = new Size(174, 23);
            txtNick.TabIndex = 4;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(246, 271);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(174, 23);
            txtSenha.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Showcard Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(246, 169);
            label2.Name = "label2";
            label2.Size = new Size(157, 23);
            label2.TabIndex = 6;
            label2.Text = "INSIRA SEU NICK";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Showcard Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(246, 245);
            label3.Name = "label3";
            label3.Size = new Size(174, 23);
            label3.TabIndex = 7;
            label3.Text = "INSIRA SUA SENHA";
            // 
            // btnEntrar
            // 
            btnEntrar.Font = new Font("Showcard Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEntrar.Location = new Point(113, 333);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(139, 52);
            btnEntrar.TabIndex = 8;
            btnEntrar.Text = "ENTRAR";
            btnEntrar.UseVisualStyleBackColor = true;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.quebracabeca;
            ClientSize = new Size(689, 450);
            Controls.Add(btnEntrar);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtSenha);
            Controls.Add(txtNick);
            Controls.Add(btnCadastrar);
            Controls.Add(btnSair);
            Controls.Add(label1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmLogin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSair;
        private Button btnCadastrar;
        private TextBox txtNick;
        private TextBox txtSenha;
        private Label label2;
        private Label label3;
        private Button btnEntrar;
    }
}