﻿namespace ProjetoIntegrador
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            gbPuzzleBox = new GroupBox();
            pbx9 = new PictureBox();
            pbx8 = new PictureBox();
            pbx7 = new PictureBox();
            pbx6 = new PictureBox();
            pbx5 = new PictureBox();
            pbx4 = new PictureBox();
            pbx3 = new PictureBox();
            pbx2 = new PictureBox();
            pbx1 = new PictureBox();
            gbOriginal = new GroupBox();
            pictureBox1 = new PictureBox();
            lblMovimento = new Label();
            btnEmbaralhar = new Button();
            btnPausar = new Button();
            btnSair = new Button();
            lblTempo = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            gbPuzzleBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbx9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbx1).BeginInit();
            gbOriginal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // gbPuzzleBox
            // 
            gbPuzzleBox.Controls.Add(pbx9);
            gbPuzzleBox.Controls.Add(pbx8);
            gbPuzzleBox.Controls.Add(pbx7);
            gbPuzzleBox.Controls.Add(pbx6);
            gbPuzzleBox.Controls.Add(pbx5);
            gbPuzzleBox.Controls.Add(pbx4);
            gbPuzzleBox.Controls.Add(pbx3);
            gbPuzzleBox.Controls.Add(pbx2);
            gbPuzzleBox.Controls.Add(pbx1);
            gbPuzzleBox.Location = new Point(12, 12);
            gbPuzzleBox.Name = "gbPuzzleBox";
            gbPuzzleBox.Size = new Size(586, 544);
            gbPuzzleBox.TabIndex = 0;
            gbPuzzleBox.TabStop = false;
            gbPuzzleBox.Text = "Fotos Do Puzzle";
            // 
            // pbx9
            // 
            pbx9.Location = new Point(390, 362);
            pbx9.Name = "pbx9";
            pbx9.Size = new Size(186, 164);
            pbx9.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx9.TabIndex = 8;
            pbx9.TabStop = false;
            // 
            // pbx8
            // 
            pbx8.Location = new Point(198, 362);
            pbx8.Name = "pbx8";
            pbx8.Size = new Size(186, 164);
            pbx8.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx8.TabIndex = 7;
            pbx8.TabStop = false;
            // 
            // pbx7
            // 
            pbx7.Location = new Point(6, 362);
            pbx7.Name = "pbx7";
            pbx7.Size = new Size(186, 164);
            pbx7.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx7.TabIndex = 6;
            pbx7.TabStop = false;
            // 
            // pbx6
            // 
            pbx6.Location = new Point(390, 192);
            pbx6.Name = "pbx6";
            pbx6.Size = new Size(186, 164);
            pbx6.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx6.TabIndex = 5;
            pbx6.TabStop = false;
            // 
            // pbx5
            // 
            pbx5.Location = new Point(198, 192);
            pbx5.Name = "pbx5";
            pbx5.Size = new Size(186, 164);
            pbx5.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx5.TabIndex = 4;
            pbx5.TabStop = false;
            // 
            // pbx4
            // 
            pbx4.Location = new Point(6, 192);
            pbx4.Name = "pbx4";
            pbx4.Size = new Size(186, 164);
            pbx4.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx4.TabIndex = 3;
            pbx4.TabStop = false;
            // 
            // pbx3
            // 
            pbx3.Location = new Point(390, 22);
            pbx3.Name = "pbx3";
            pbx3.Size = new Size(186, 164);
            pbx3.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx3.TabIndex = 2;
            pbx3.TabStop = false;
            // 
            // pbx2
            // 
            pbx2.Location = new Point(198, 22);
            pbx2.Name = "pbx2";
            pbx2.Size = new Size(186, 164);
            pbx2.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx2.TabIndex = 1;
            pbx2.TabStop = false;
            // 
            // pbx1
            // 
            pbx1.Location = new Point(6, 22);
            pbx1.Name = "pbx1";
            pbx1.Size = new Size(186, 164);
            pbx1.SizeMode = PictureBoxSizeMode.StretchImage;
            pbx1.TabIndex = 0;
            pbx1.TabStop = false;
            // 
            // gbOriginal
            // 
            gbOriginal.Controls.Add(pictureBox1);
            gbOriginal.Location = new Point(676, 12);
            gbOriginal.Name = "gbOriginal";
            gbOriginal.Size = new Size(388, 345);
            gbOriginal.TabIndex = 1;
            gbOriginal.TabStop = false;
            gbOriginal.Text = "Foto Original";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.original;
            pictureBox1.Location = new Point(5, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(381, 327);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // lblMovimento
            // 
            lblMovimento.AutoSize = true;
            lblMovimento.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMovimento.ForeColor = SystemColors.MenuHighlight;
            lblMovimento.Location = new Point(18, 587);
            lblMovimento.Name = "lblMovimento";
            lblMovimento.Size = new Size(261, 30);
            lblMovimento.TabIndex = 2;
            lblMovimento.Text = "MOVIMENTOS FEITOS:";
            // 
            // btnEmbaralhar
            // 
            btnEmbaralhar.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEmbaralhar.Location = new Point(697, 535);
            btnEmbaralhar.Name = "btnEmbaralhar";
            btnEmbaralhar.Size = new Size(103, 39);
            btnEmbaralhar.TabIndex = 3;
            btnEmbaralhar.Text = "EMBARALHAR";
            btnEmbaralhar.UseVisualStyleBackColor = true;
            btnEmbaralhar.Click += btnEmbaralhar_Click;
            // 
            // btnPausar
            // 
            btnPausar.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnPausar.Location = new Point(816, 535);
            btnPausar.Name = "btnPausar";
            btnPausar.Size = new Size(103, 39);
            btnPausar.TabIndex = 4;
            btnPausar.Text = "PAUSAR";
            btnPausar.UseVisualStyleBackColor = true;
            btnPausar.Click += btnPausar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(936, 535);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(103, 39);
            btnSair.TabIndex = 5;
            btnSair.Text = "SAIR";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // lblTempo
            // 
            lblTempo.AutoSize = true;
            lblTempo.Font = new Font("Showcard Gothic", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTempo.Location = new Point(714, 403);
            lblTempo.Name = "lblTempo";
            lblTempo.Size = new Size(306, 79);
            lblTempo.TabIndex = 6;
            lblTempo.Text = "00:00:00";
            lblTempo.Click += lblTempo_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += UpdateTimeElapsed;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1138, 662);
            Controls.Add(lblTempo);
            Controls.Add(btnSair);
            Controls.Add(btnPausar);
            Controls.Add(btnEmbaralhar);
            Controls.Add(lblMovimento);
            Controls.Add(gbOriginal);
            Controls.Add(gbPuzzleBox);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PUZZLE IMAGEM";
            Load += Form1_Load_1;
            gbPuzzleBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbx9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbx1).EndInit();
            gbOriginal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox gbPuzzleBox;
        private GroupBox gbOriginal;
        private PictureBox pbx1;
        private PictureBox pbx9;
        private PictureBox pbx8;
        private PictureBox pbx7;
        private PictureBox pbx6;
        private PictureBox pbx5;
        private PictureBox pbx4;
        private PictureBox pbx3;
        private PictureBox pbx2;
        private Label lblMovimento;
        private Button btnEmbaralhar;
        private Button btnPausar;
        private Button btnSair;
        private PictureBox pictureBox1;
        private Label lblTempo;
        private System.Windows.Forms.Timer timer1;
    }
}
