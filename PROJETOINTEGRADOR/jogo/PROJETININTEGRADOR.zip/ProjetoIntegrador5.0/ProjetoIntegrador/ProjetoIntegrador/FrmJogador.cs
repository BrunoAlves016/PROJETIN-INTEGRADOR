﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIntegrador
{
    public partial class FrmJogador : Form
    {
        public FrmJogador()
        {
            InitializeComponent();
        }
        #region LIXEIRA

        private void dgJogador_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        #endregion
        private void dgJogador_MouseClick(object sender, MouseEventArgs e)
        {
            // Verifica se as colunas já não foram adicionadas antes
            if (dgJogador.Columns.Count == 0)
            {
                // Cria a coluna "Jogadores"
                DataGridViewTextBoxColumn colJogadores = new DataGridViewTextBoxColumn();
                colJogadores.Name = "Jogadores";
                colJogadores.HeaderText = "Jogadores";

                // Cria a coluna "Nick"
                DataGridViewTextBoxColumn colNick = new DataGridViewTextBoxColumn();
                colNick.Name = "Nick";
                colNick.HeaderText = "Nick";

                // Adiciona as colunas ao DataGridView
                dgJogador.Columns.Add(colJogadores);
                dgJogador.Columns.Add(colNick);
            }
        }
        public void AdicionarJogador(string nome, string nick)
        {
            // Verifica se as colunas existem
            if (dgJogador.Columns.Count == 0)
            {
                // Cria as colunas se elas não existirem
                dgJogador.Columns.Add("Jogadores", "Jogadores");
                dgJogador.Columns.Add("Nick", "Nick");
            }

            // Adiciona uma nova linha ao DataGridView
            dgJogador.Rows.Add(nome, nick);
        }
    }
}
