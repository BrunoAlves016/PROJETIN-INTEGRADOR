﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIntegrador
{
    public partial class FrmNick : Form
    {
        private FrmJogador frmJogador;
        public FrmNick(FrmJogador FrmJogador)
        {
            InitializeComponent();
            this.frmJogador = FrmJogador; // Guarda a referência do FrmJogador
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            // Verifica se os campos de texto não estão vazios
            if (!string.IsNullOrEmpty(txtNome.Text) && !string.IsNullOrEmpty(txtNick.Text))
            {
                // Envia os valores dos TextBox para o FrmJogador
                frmJogador.AdicionarJogador(txtNome.Text, txtNick.Text);
            }
            else
            {
                // Exibe uma mensagem se os campos estiverem vazios
                MessageBox.Show("Por favor, insira o Nome e o Nick.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            // Verifica se os campos estão preenchidos
            if (string.IsNullOrEmpty(txtNome.Text) || string.IsNullOrEmpty(txtNick.Text))
            {
                // Exibe uma mensagem se os campos estiverem vazios
                MessageBox.Show("Por favor, preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;  // Interrompe a execução do método se os campos estiverem vazios
            }

            // Instancia o formulário FrmLogin
            FrmLogin frmLogin = new FrmLogin();

            // Abre o FrmLogin
            frmLogin.Show();

            // Opcional: Fechar ou esconder o FrmNick (se desejar)
            this.Hide();  // Esconde o FrmNick para mostrar o FrmLogin
        }

        private void VerificarCampos()
        {
            btnEntrar.Enabled = !string.IsNullOrEmpty(txtNome.Text) && !string.IsNullOrEmpty(txtNick.Text);

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            VerificarCampos();  // Verifica os campos sempre que o texto mudar

        }

        private void txtNick_TextChanged(object sender, EventArgs e)
        {
            VerificarCampos();  // Verifica os campos sempre que o texto mudar

        }


        #region LIXEIRA

        private void button1_Click(object sender, EventArgs e)
        {

        }
        #endregion
    }
}
