﻿namespace ProjetoIntegrador
{
    partial class FrmCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNick = new TextBox();
            txtSenha = new TextBox();
            label2 = new Label();
            label3 = new Label();
            btnCadastro = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.Font = new Font("Showcard Gothic", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(117, 41);
            label1.Name = "label1";
            label1.Size = new Size(352, 44);
            label1.TabIndex = 0;
            label1.Text = "CADASTRO DO JOGO";
            // 
            // txtNick
            // 
            txtNick.Location = new Point(192, 194);
            txtNick.Name = "txtNick";
            txtNick.Size = new Size(182, 23);
            txtNick.TabIndex = 1;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(192, 263);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(182, 23);
            txtSenha.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaptionText;
            label2.Font = new Font("Showcard Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(192, 168);
            label2.Name = "label2";
            label2.Size = new Size(157, 23);
            label2.TabIndex = 3;
            label2.Text = "INSIRA SEU NICK";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaptionText;
            label3.Font = new Font("Showcard Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(192, 237);
            label3.Name = "label3";
            label3.Size = new Size(174, 23);
            label3.TabIndex = 4;
            label3.Text = "INSIRA SUA SENHA";
            // 
            // btnCadastro
            // 
            btnCadastro.Font = new Font("Showcard Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastro.Location = new Point(207, 311);
            btnCadastro.Name = "btnCadastro";
            btnCadastro.Size = new Size(142, 45);
            btnCadastro.TabIndex = 5;
            btnCadastro.Text = "CADASTRAR";
            btnCadastro.UseVisualStyleBackColor = true;
            btnCadastro.Click += btnCadastro_Click;
            // 
            // FrmCadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.puzzleimage;
            ClientSize = new Size(612, 394);
            Controls.Add(btnCadastro);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtSenha);
            Controls.Add(txtNick);
            Controls.Add(label1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmCadastro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmCadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNick;
        private TextBox txtSenha;
        private Label label2;
        private Label label3;
        private Button btnCadastro;
    }
}