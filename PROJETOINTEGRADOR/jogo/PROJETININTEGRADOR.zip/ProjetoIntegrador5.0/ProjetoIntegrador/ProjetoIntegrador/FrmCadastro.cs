﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIntegrador
{
    public partial class FrmCadastro : Form
    {
        public FrmCadastro()
        {
            InitializeComponent();
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            // Verifica se os campos estão preenchidos
            if (string.IsNullOrWhiteSpace(txtNick.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("POR FAVOR PREENCHA OS CAMPOS", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // Armazena o nick e senha inseridos
                FrmLogin.NickCadastrado = txtNick.Text;
                FrmLogin.SenhaCadastrada = txtSenha.Text;

                // Exibe mensagem de sucesso e fecha o formulário de cadastro
                MessageBox.Show("CADASTRO CONCLUÍDO COM SUCESSO", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
    }
}

