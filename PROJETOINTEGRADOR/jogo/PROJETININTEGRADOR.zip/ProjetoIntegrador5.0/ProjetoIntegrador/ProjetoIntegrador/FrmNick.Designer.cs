﻿namespace ProjetoIntegrador
{
    partial class FrmNick
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtNome = new TextBox();
            label3 = new Label();
            txtNick = new TextBox();
            btnSalvar = new Button();
            btnEntrar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Showcard Gothic", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(62, 72);
            label1.Name = "label1";
            label1.Size = new Size(566, 46);
            label1.TabIndex = 0;
            label1.Text = "BEM-VINDOS AO PUZZLE IMAGE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(231, 213);
            label2.Name = "label2";
            label2.Size = new Size(205, 30);
            label2.TabIndex = 1;
            label2.Text = "INSIRA SEU NOME";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(231, 246);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(196, 23);
            txtNome.TabIndex = 2;
            txtNome.TextChanged += txtNome_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonFace;
            label3.Location = new Point(231, 302);
            label3.Name = "label3";
            label3.Size = new Size(194, 30);
            label3.TabIndex = 3;
            label3.Text = "INSIRA SEU NICK";
            // 
            // txtNick
            // 
            txtNick.Location = new Point(231, 335);
            txtNick.Name = "txtNick";
            txtNick.Size = new Size(196, 23);
            txtNick.TabIndex = 4;
            txtNick.TextChanged += txtNick_TextChanged;
            // 
            // btnSalvar
            // 
            btnSalvar.Font = new Font("Showcard Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalvar.Location = new Point(341, 397);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(120, 48);
            btnSalvar.TabIndex = 6;
            btnSalvar.Text = "CADASTRAR";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnEntrar
            // 
            btnEntrar.Font = new Font("Showcard Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEntrar.Location = new Point(203, 397);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(120, 48);
            btnEntrar.TabIndex = 7;
            btnEntrar.Text = "ENTRAR";
            btnEntrar.UseVisualStyleBackColor = true;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // FrmNick
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.quebracabeca;
            ClientSize = new Size(685, 513);
            Controls.Add(btnEntrar);
            Controls.Add(btnSalvar);
            Controls.Add(txtNick);
            Controls.Add(label3);
            Controls.Add(txtNome);
            Controls.Add(label2);
            Controls.Add(label1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmNick";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmNick";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtNome;
        private Label label3;
        private TextBox txtNick;
        private Button btnSalvar;
        private Button btnEntrar;
    }
}